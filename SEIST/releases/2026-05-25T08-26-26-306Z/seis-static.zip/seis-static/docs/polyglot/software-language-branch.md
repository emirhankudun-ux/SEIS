# Software Language Branch

## Branch

```text
UIXAppTTR
```

## Purpose

This single development branch keeps the web product lightweight while making the repository ready for many software languages:

- JavaScript for browser experience.
- TypeScript for release contract typing.
- Node.js for build and validation scripts.
- Python for metadata inspection and automation.
- Ruby for alternate release verification.
- PHP for shared-hosting health fallback.
- Go for future service health contracts.
- Rust for performance-budget contracts.
- Swift for iOS motion/accessibility policy.
- Kotlin for Android motion/accessibility policy.
- Dart for Flutter-facing motion policy.
- Bash for portable deploy guards.
- Java for JVM-side deploy readiness contracts.
- C# for .NET release preservation contracts.
- SQL for a future release ledger schema.
- Lua for tiny edge/device policy reuse.
- YAML for portable deploy governance configuration.
- C++ for native release contract headers.
- Elixir for functional release and locale contracts.
- Scala for JVM functional release contracts.
- Clojure for data-first release contracts.
- Cloudflare Worker for edge health/origin proxy.
- Docker for containerized serving.
- Nginx/Apache config for static hosting rewrite and cache behavior.
- R for analytics-facing motion budget contracts.
- Julia for scientific and optimization-facing release contracts.
- Haskell for pure functional release contracts.
- Erlang for fault-tolerant release status contracts.
- Zig for systems-level performance budget contracts.
- Nim for compiled motion policy contracts.
- Perl for portable manifest verification.
- F# for .NET functional release contracts.
- Objective-C for legacy Apple platform motion policy bridges.
- Racket for language-oriented release contracts.
- OCaml for typed functional release contracts.
- PowerShell for Windows-friendly release guards.
- Terraform for infrastructure upload guard contracts.
- GraphQL for future API schema contracts.
- Protocol Buffers for future service message contracts.
- TOML for portable deploy governance contracts.

## Constraint

These language surfaces are contracts and tiny utilities only. They do not introduce package managers, build systems, or dependency bloat yet.

## Added Server Code

- `server/node/static-server.mjs`
- `server/php/health.php`
- `server/php/router.php`
- `server/python/verify_release.py`
- `server/edge/cloudflare-worker.js`
- `server/docker/Dockerfile`
- `polyglot/ruby/verify_release.rb`
- `polyglot/dart/seis_motion_policy.dart`
- `polyglot/bash/deploy_guard.sh`
- `polyglot/typescript/release-contract.ts`
- `polyglot/java/SeisDeployReadiness.java`
- `polyglot/csharp/SeisReleaseContract.cs`
- `polyglot/sql/release_readiness_schema.sql`
- `polyglot/lua/calm_motion_policy.lua`
- `polyglot/yaml/deploy-governance.yml`
- `polyglot/cpp/seis_release_contract.hpp`
- `polyglot/elixir/seis_release_contract.ex`
- `polyglot/scala/SeisReleaseContract.scala`
- `polyglot/clojure/seis_release_contract.clj`
- `server/nginx/seis-static.conf`
- `server/apache/.htaccess`
- `polyglot/r/seis_motion_budget.R`
- `polyglot/julia/SeisReleaseContract.jl`
- `polyglot/haskell/SeisReleaseContract.hs`
- `polyglot/erlang/seis_release_contract.erl`
- `polyglot/zig/seis_budget.zig`
- `polyglot/nim/seis_motion_policy.nim`
- `polyglot/perl/verify_manifest.pl`
- `polyglot/fsharp/SeisReleaseContract.fs`
- `polyglot/objective-c/SEISMotionPolicy.h`
- `polyglot/racket/seis-release-contract.rkt`
- `polyglot/ocaml/seis_release_contract.ml`
- `polyglot/powershell/Test-SeisRelease.ps1`
- `polyglot/terraform/seis_deploy_guard.tf`
- `polyglot/graphql/seis_schema.graphql`
- `polyglot/protobuf/seis_release.proto`
- `polyglot/toml/deploy-governance.toml`
