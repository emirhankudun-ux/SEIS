# Development Process

SEIS development starts from a calm, modular, low-power rhythm. Each change should improve one explainable layer without forcing a broad rebuild, dependency expansion, or remote operation before the repository state is clear.

## Active Branch Contract

- GitHub should keep `UIXAppTTR` as the single remote branch for this project.
- `main` remains sacred as a philosophy, but it should not exist as an active remote branch for the current UIXAppTTR-only GitHub shape.
- Remote branch deletion requires working GitHub authentication before execution.
- Local conflict resolution and remote branch cleanup are separate operations.

## Development Cadence

| Phase | Purpose | Lightweight Proof |
| --- | --- | --- |
| Orient | Read the nearest docs, scripts, and target files. | Current surface is named before edits. |
| Compose | Make one reversible modular improvement. | The change has a rollback path. |
| Verify | Run the smallest relevant checks. | Syntax and focused governance checks pass. |
| Publish | Ship only after auth and branch state are explicit. | Remote head and branch list are confirmed. |

## First Slice

The first development slice is calm foundation hardening:

- Add a machine-readable development process registry.
- Add this human-readable governance protocol.
- Add a lightweight script that checks the protocol exists and remains aligned with the UIXAppTTR branch contract.

## Active Sprint

The current sprint adds a visible development cockpit and closes missing operational surfaces without introducing a new dependency stack.

| Workstream | Status | Proof |
| --- | --- | --- |
| Experience cockpit | In progress | Public shell exposes the active development cadence. |
| Server handoff | Ready for confirmed target | `dist/server-drop` contains zip, manifest, upload plan, and latest pointer. |
| Polyglot branch | Expanded | Language surfaces stay small contracts without dependency bloat. |
| Quality gates | Active | Syntax, foundation, release, history, and server-drop checks stay green. |

## Open Backlog

| ID | Priority | Missing Surface |
| --- | --- | --- |
| `dev-002` | High | Server target confirmation flow. |
| `dev-003` | Medium | Case study detail model. |
| `dev-004` | Medium | Accessibility review checklist. |
| `dev-005` | Low | Framework migration decision record. |

## Stop Conditions

Stop and report clearly when:

- GitHub authentication is missing.
- The current folder is not the intended Git working tree.
- A change would require a heavy build, broad indexing, or dependency installation without explicit need.
- Branch cleanup would delete remote history without confirming the protected branch first.

## Quality Bias

Prefer small, composable changes with visible acceptance criteria. Keep motion restrained, accessibility explicit, and documentation close enough to the code that future changes stay explainable.
