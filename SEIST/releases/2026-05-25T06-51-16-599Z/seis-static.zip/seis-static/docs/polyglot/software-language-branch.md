# Software Language Branch

## Branch

```text
feature/polyglot-multilingual-server-foundation
```

## Purpose

This branch keeps the web product lightweight while making the repository ready for many software languages:

- JavaScript for browser experience.
- TypeScript for release contract typing.
- Node.js for build and validation scripts.
- Python for metadata inspection and automation.
- Ruby for alternate release verification.
- PHP for shared-hosting health fallback.
- Go for future service health contracts.
- Rust for performance-budget contracts.
- Swift for iOS motion/accessibility policy.
- Kotlin for Android motion/accessibility policy.
- Dart for Flutter-facing motion policy.
- Bash for portable deploy guards.
- Java for JVM-side deploy readiness contracts.
- C# for .NET release preservation contracts.
- SQL for a future release ledger schema.
- Lua for tiny edge/device policy reuse.
- YAML for portable deploy governance configuration.
- Cloudflare Worker for edge health/origin proxy.
- Docker for containerized serving.
- Nginx/Apache config for static hosting rewrite and cache behavior.

## Constraint

These language surfaces are contracts and tiny utilities only. They do not introduce package managers, build systems, or dependency bloat yet.

## Added Server Code

- `server/node/static-server.mjs`
- `server/php/health.php`
- `server/php/router.php`
- `server/python/verify_release.py`
- `server/edge/cloudflare-worker.js`
- `server/docker/Dockerfile`
- `polyglot/ruby/verify_release.rb`
- `polyglot/dart/seis_motion_policy.dart`
- `polyglot/bash/deploy_guard.sh`
- `polyglot/typescript/release-contract.ts`
- `polyglot/java/SeisDeployReadiness.java`
- `polyglot/csharp/SeisReleaseContract.cs`
- `polyglot/sql/release_readiness_schema.sql`
- `polyglot/lua/calm_motion_policy.lua`
- `polyglot/yaml/deploy-governance.yml`
- `server/nginx/seis-static.conf`
- `server/apache/.htaccess`
