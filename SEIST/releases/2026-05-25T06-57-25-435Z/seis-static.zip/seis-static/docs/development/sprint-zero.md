# Sprint Zero

## Goal

Begin SEIS development without breaking the calm, dependency-light foundation.

## Active Lanes

| Lane | Purpose | Gate |
| --- | --- | --- |
| Interface polish | Improve the first usable product surface. | Responsive and accessible before visual density. |
| Motion tuning | Keep cinematic movement calm and controllable. | Reduced-motion and mobile frame budget first. |
| Release safety | Preserve every server-ready package. | Package, hash, backup, handoff before upload. |
| Polyglot growth | Keep many-language readiness lightweight. | Contracts before services. |

## First Decisions

- Confirm the first production server target.
- Choose the first user-facing product route.
- Decide whether mobile starts as Expo, native Swift/Kotlin, or PWA-first.

## Operating Files

- `content/development/backlog.json`
- `content/development/decision-log.json`
- `docs/development/development-summary.md`
