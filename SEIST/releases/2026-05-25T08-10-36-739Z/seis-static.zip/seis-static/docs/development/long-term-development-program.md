# UIXAppTTR Long-Term Development Program

SEIS grows through calm, modular, long-running development. The goal is not to produce one large unstable branch, but to keep a durable branch rhythm where each layer can be reviewed, packaged, rolled back, and explained.

## Operating Horizon

- Branch: `UIXAppTTR`
- Mode: low-power modular development
- Unit: small reversible increments
- Release rule: package, hash, backup, and handoff before upload
- Server rule: live upload stays blocked until domain, host, path, and rollback are confirmed

## Phase Plan

| Phase | Status | Focus | Exit Gate |
| --- | --- | --- | --- |
| Foundation Integrity | Active | Stable, accessible, responsive static surface | Foundation, locale, experience budget, and release checks pass together |
| Cinematic Interface System | Planned | Hero, section rhythm, reveal, tactile depth | Reduced-motion and mobile frame budget remain protected |
| Mobile Product Path | Planned | PWA-first hardening before native expansion | Touch targets, installability, offline behavior, and responsive routes are verified |
| Server Preservation | Blocked | Upload only after target confirmation | Server target confirmed and checksum match recorded |
| Polyglot Service Promotion | Deferred | Promote only proven contracts into services | Contract, owner, runtime cost, and rollback path documented |
| Observability And Governance | Planned | Useful signals without dashboard overload | Signals are minimal, privacy-aware, and tied to decisions |

## Standing Rules

- Main stays protected.
- `UIXAppTTR` remains the single active development branch.
- Sub-agents operate as workstreams inside `UIXAppTTR`.
- No heavy dependency is added without a promotion gate.
- Server upload remains blocked until the active target is confirmed.
- Reduced-motion and mobile performance remain mandatory.

## Long-Run Moves

1. Expand the visible cockpit with phase progress.
2. Turn release guardrails into server-specific handoff steps after target selection.
3. Promote the mobile path from decision matrix into installable PWA hardening.
4. Add visual QA snapshots only when a page surface materially changes.

## Review Pattern

Every long-running update should answer four questions before commit:

- What user-facing or governance surface changed?
- Which quality gate protects it?
- Which rollback path exists?
- Which future phase becomes easier because of this work?
