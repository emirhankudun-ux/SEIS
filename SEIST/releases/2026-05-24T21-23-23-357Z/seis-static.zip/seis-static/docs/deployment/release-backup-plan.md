# Release Backup Plan

## Goal

Keep every deployable SEIS package recoverable even before a live server target is confirmed.

## Commands

```bash
npm run check:release
npm run backup:release
```

The backup command writes:

```text
releases/<timestamp>/seis-static.zip
releases/<timestamp>/server-upload-manifest.json
releases/latest.json
```

## Server Rule

Only upload a package whose SHA-256 matches `server-upload-manifest.json`.

