# Software Language Branch

## Branch

```text
feature/polyglot-multilingual-server-foundation
```

## Purpose

This branch keeps the web product lightweight while making the repository ready for many software languages:

- JavaScript for browser experience.
- TypeScript for release contract typing.
- Node.js for build and validation scripts.
- Python for metadata inspection and automation.
- Ruby for alternate release verification.
- PHP for shared-hosting health fallback.
- Go for future service health contracts.
- Rust for performance-budget contracts.
- Swift for iOS motion/accessibility policy.
- Kotlin for Android motion/accessibility policy.
- Dart for Flutter-facing motion policy.
- Bash for portable deploy guards.
- Java for JVM-side deploy readiness contracts.
- C# for .NET release preservation contracts.
- SQL for a future release ledger schema.
- Lua for tiny edge/device policy reuse.
- YAML for portable deploy governance configuration.
- Cloudflare Worker for edge health/origin proxy.
- Docker for containerized serving.
- Nginx/Apache config for static hosting rewrite and cache behavior.
- C and C++ for native readiness contracts.
- Elixir and Erlang for concurrent/fault-tolerant release policy sketches.
- Haskell, Scala, Clojure, and F# for functional typed policy models.
- R and Julia for future readiness analysis notebooks.
- Perl for legacy hosting guard scripts.
- Zig for systems-level readiness contracts.
- PowerShell for Windows operations release policy guards.
- TOML for portable governance configuration.
- XML for enterprise interchange release policy contracts.

## Constraint

These language surfaces are contracts and tiny utilities only. They do not introduce package managers, build systems, or dependency bloat yet.

## Added Server Code

- `server/node/static-server.mjs`
- `server/php/health.php`
- `server/php/router.php`
- `server/python/verify_release.py`
- `server/edge/cloudflare-worker.js`
- `server/docker/Dockerfile`
- `polyglot/ruby/verify_release.rb`
- `polyglot/dart/seis_motion_policy.dart`
- `polyglot/bash/deploy_guard.sh`
- `polyglot/typescript/release-contract.ts`
- `polyglot/java/SeisDeployReadiness.java`
- `polyglot/csharp/SeisReleaseContract.cs`
- `polyglot/sql/release_readiness_schema.sql`
- `polyglot/lua/calm_motion_policy.lua`
- `polyglot/yaml/deploy-governance.yml`
- `server/nginx/seis-static.conf`
- `server/apache/.htaccess`
- `polyglot/c/readiness_contract.h`
- `polyglot/cpp/readiness_contract.hpp`
- `polyglot/elixir/calm_release_policy.ex`
- `polyglot/erlang/calm_release_policy.erl`
- `polyglot/haskell/CalmReleasePolicy.hs`
- `polyglot/scala/SeisReleasePolicy.scala`
- `polyglot/r/readiness_metrics.R`
- `polyglot/julia/readiness_metrics.jl`
- `polyglot/perl/readiness_guard.pl`
- `polyglot/zig/readiness_contract.zig`
- `polyglot/clojure/readiness_policy.clj`
- `polyglot/fsharp/SeisReleasePolicy.fs`
- `polyglot/powershell/SeisReleasePolicy.ps1`
- `polyglot/toml/deploy-governance.toml`
- `polyglot/xml/release-policy.xml`
